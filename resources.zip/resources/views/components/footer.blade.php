<footer class="main-footer">
    <div class="footer-left">
        </a>
    </div>
    <div class="footer-right">
        V1.3
    </div>
</footer>
