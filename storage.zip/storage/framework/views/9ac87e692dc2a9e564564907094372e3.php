<?php $__env->startSection('content'); ?>
    <!-- Hero Section -->
    <section class="hero-section">
        <div class="container my-5">
            <div class="hero row align-items-center">
              <div class="col-lg-6 hero-text">
                <p class="text-uppercase fw-bold text-pink" style="color:#fff">Selamat Datang</p>
                <h1 class="display-5 mb-3">Sembuh dan Tumbuh Bersama Sastra</h1>
                <p>Media Literasi untuk Pemberdayaan dan Kesehatan Mental Warga Binaan Perempuan</p>
                <button class="btn btn-primary mt-3">Read more</button>
              </div>
              <div class="col-lg-6 hero-image mt-4 mt-lg-0 text-center">
                <img src="<?php echo e(asset('FE_JELITA/assets/img/book.png')); ?>" alt=" Art"> <!-- Ganti your-image.jpg dengan path gambar kamu -->
              </div>
            </div>
          </div>
    </section>

    <!-- Search Section -->
    <section class="search-section py-5">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <form action="<?php echo e(route('pojok-cerita.search')); ?>" method="GET" class="search-form">
                        <div class="row g-3">
                            <div class="col-md-5">
                                <input type="text" name="title" class="form-control" placeholder="Tulis Judul Disini" value="<?php echo e(request('title')); ?>">
                            </div>
                            <div class="col-md-5">
                                <select name="category" class="form-select">
                                    <option value="">Semua Genre</option>
                                    <option value="CERPEN" <?php echo e(request('category') == 'CERPEN' ? 'selected' : ''); ?>>Cerpen</option>
                                    <option value="PUISI" <?php echo e(request('category') == 'PUISI' ? 'selected' : ''); ?>>Puisi</option>
                                    <option value="KARYA PEGAWAI" <?php echo e(request('category') == 'KARYA PEGAWAI' ? 'selected' : ''); ?>>Karya Pegawai</option>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <button type="submit" class="btn btn-primary w-100">Cari Judul</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <!-- Featured Sections -->
    <section class="featured-section py-5">
        <div class="container my-5">
            <div class="row g-4">
              <div class="col-md-6">
                <div class="book-card p-4 rounded-4 bg-light">
                  <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="fw-bold mb-0">Baru Saja Terbit</h5>
                  </div>
                  <ul class="list-unstyled mb-0">
                    <?php $__currentLoopData = ($recentArticles ?? []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li class="mb-3 d-flex align-items-start">
                        <img src="<?php echo e(asset('storage/' . $item->image)); ?>" alt="<?php echo e($item->title); ?>" class="rounded me-3" style="width:60px;height:60px;object-fit:cover;">
                        <div>
                          <a href="<?php echo e(route('pojok-cerita.thumb', $item->id)); ?>" class="fw-semibold text-white text-decoration-none"><?php echo e($item->title); ?></a>
                          <div class="small text-white"><?php echo e($item->created_at->format('d M Y')); ?></div>
                        </div>
                      </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
                </div>
              </div>
              <div class="col-md-6">
                <div class="book-card p-4 rounded-4 bg-light">
                  <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="fw-bold mb-0">Terpopuler</h5>
                  </div>
                  <ul class="list-unstyled mb-0">
                    <?php $__currentLoopData = ($popularArticles ?? []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li class="mb-3 d-flex align-items-start">
                        <img src="<?php echo e(asset('storage/' . $item->image)); ?>" alt="<?php echo e($item->title); ?>" class="rounded me-3" style="width:60px;height:60px;object-fit:cover;">
                        <div>
                          <a href="<?php echo e(route('pojok-cerita.thumb', $item->id)); ?>" class="fw-semibold text-white text-decoration-none"><?php echo e($item->title); ?></a>
                          <div class="small text-white"><?php echo e(number_format((int)($item->views ?? 0))); ?> kali dibaca</div>
                        </div>
                      </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
                </div>
              </div>
            </div>
          </div>
    </section>

    <!-- Rekomendasi Section -->
    <section class="recommendation-section py-5">
        <div class="container">
            <div class="section-header d-flex justify-content-between align-items-center mb-5">
                <h2 class="section-title">Rekomendasi Jelita</h2>
                <button class="btn btn-primary">View All</button>
            </div>
            
            <!-- Main Article -->
            <?php if($mainArticle): ?>
            <div class="row mb-5">
                <div class="col-lg-12">
                    <div class="main-article">
                        <div class="row">
                            <div class="col-md-4">
                                <img src="<?php echo e(asset('storage/' . $mainArticle->image)); ?>" 
                                    class="img-fluid rounded" 
                                    alt="<?php echo e($mainArticle->title); ?>">
                            </div>
                            <div class="col-md-8">
                                <div class="article-content">
                                    <div class="article-meta">
                                        <span class="badge bg-secondary"><?php echo e(strtoupper($mainArticle->category)); ?></span>
                                        <span class="text-muted ms-2"><?php echo e($mainArticle->created_at->format('d F Y')); ?></span>
                                        <span class="text-muted ms-2"><?php echo e(number_format((int)($mainArticle->views ?? 0))); ?> kali dibaca</span>
                                    </div>
                                    <h3 class="article-title"><?php echo e($mainArticle->title); ?></h3>
                                    <p class="article-excerpt">
                                        <?php echo e(Str::limit(strip_tags($mainArticle->body), 150, '...')); ?>

                                    </p>
                                    <a href="<?php echo e(route('pojok-cerita.thumb', $mainArticle->id)); ?>" class="text-primary text-decoration-none">Read More...</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            

            <!-- Small Articles -->
            <div class="row g-4">
              <?php $__currentLoopData = $smallArticles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-lg-4 col-md-6">
                  <div class="article-card">
                      <img src="<?php echo e(asset('storage/' . $article->image)); ?>" 
                           class="card-img-top rounded-4" 
                           alt="<?php echo e($article->title); ?>">
                      <div class="card-body px-0">
                          <div class="article-meta mb-2">
                              <br>
                              <span class="text-pink fw-bold"><?php echo e(ucfirst(strtolower($article->category))); ?></span>
                              <span class="text-muted ms-2"><?php echo e($article->created_at->format('d F Y')); ?></span>
                              <span class="text-muted ms-2"><?php echo e(number_format((int)($article->views ?? 0))); ?> kali dibaca</span>
                          </div>
                          <h5 class="fw-bold text-dark"><?php echo e($article->title); ?></h5>
                          <p class="text-muted small"><?php echo e(Str::limit(strip_tags($article->body), 100, '...')); ?></p>
                          <a href="<?php echo e(route('pojok-cerita.thumb', $article->id)); ?>" class="text-pink fw-bold text-decoration-none">Read More...</a>
                      </div>
                  </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
  
        </div>
    </section>

    <!-- News Section -->
    <section class="news-section py-5 bg-light">
        <div class="container">
            <div class="section-header d-flex justify-content-between align-items-center mb-5">
                <h2 class="section-title">Berita Terkini</h2>
                <a href="<?php echo e(route('news.index')); ?>" class="btn btn-primary">Lihat Semua</a>
            </div>
            
            <?php if($latestNews->count() > 0): ?>
                <!-- Main News Article -->
                <?php if($latestNews->first()): ?>
                <div class="row mb-5">
                    <div class="col-lg-12">
                        <div class="main-article">
                            <div class="row">
                                <div class="col-md-4">
                                  <?php if($latestNews->first()->image): ?>
                                  <img src="<?php echo e(Storage::url($latestNews->first()->image)); ?>" 
                                       class="img-fluid rounded" 
                                       alt="<?php echo e($latestNews->first()->title); ?>"
                                       style="height: 300px; object-fit: cover;">
                              <?php else: ?>
                                  <div class="bg-secondary d-flex align-items-center justify-content-center rounded" 
                                       style="height: 300px;">
                                      <i class="fas fa-newspaper fa-3x text-white"></i>
                                  </div>
                              <?php endif; ?>
                              
                                </div>
                                <div class="col-md-8">
                                    <div class="article-content">
                                        <div class="article-meta">
                                            <span class="badge bg-primary">Berita</span>
                                            <span class="text-muted ms-2"><?php echo e($latestNews->first()->created_at->format('d M Y')); ?></span>
                                        </div>
                                        <h3 class="article-title"><?php echo e($latestNews->first()->title); ?></h3>
                                        <p class="article-excerpt">
                                            <?php echo e(Str::limit(strip_tags($latestNews->first()->content), 200)); ?>

                                        </p>
                                        <a href="<?php echo e(route('news.show', $latestNews->first()->slug)); ?>" 
                                           class="text-primary text-decoration-none">Baca Selengkapnya...</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                
                <!-- News Articles Grid -->
                <div class="row g-4">
                    <?php $__currentLoopData = $latestNews->skip(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-6">
                        <div class="article-card">
                            <?php if($news->image): ?>
                                <img src="<?php echo e(Storage::url($news->image)); ?>" 
                                     class="card-img-top rounded-4" alt="<?php echo e($news->title); ?>"
                                     style="height: 200px; object-fit: cover;">
                            <?php else: ?>
                                <div class="bg-secondary d-flex align-items-center justify-content-center rounded-4" 
                                     style="height: 200px;">
                                    <i class="fas fa-newspaper fa-2x text-white"></i>
                                </div>
                            <?php endif; ?>
                            <div class="card-body px-0">
                                <div class="article-meta mb-2">
                                    <span class="badge bg-primary">Berita</span>
                                    <span class="text-muted ms-2"><?php echo e($news->created_at->format('d M Y')); ?></span>
                                </div>
                                <h5 class="fw-bold text-dark"><?php echo e($news->title); ?></h5>
                                <p class="text-muted small"><?php echo e(Str::limit(strip_tags($news->content), 120)); ?></p>
                                <a href="<?php echo e(route('news.show', $news->slug)); ?>" class="text-primary fw-bold text-decoration-none">Baca Selengkapnya...</a>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php else: ?>
                <p class="text-muted">Belum ada berita.</p>
            <?php endif; ?>

        </div>
    </section>

    <!--Partner Section-->
    <section class="partner-section py-5 bg-light">
        <div class="container text-center">
          <h2 class="mb-4 fw-bold">Dipersembahkan Oleh</h2>
          <div class="row justify-content-center align-items-center g-4">
            <div class="col-6 col-md-3 col-lg-2">
              <img src="<?php echo e(asset('FE_JELITA/assets/img/tutwuri.png')); ?>" class="img-fluid partner-logo" alt="Partner 1">
            </div>
            <div class="col-6 col-md-3 col-lg-2">
              <img src="<?php echo e(asset('FE_JELITA/assets/img/bbpss.png')); ?>" class="img-fluid partner-logo" alt="Partner 1">
            </div>
            <div class="col-6 col-md-3 col-lg-2">
              <img src="<?php echo e(asset('FE_JELITA/assets/img/dubas.png')); ?>" class="img-fluid partner-logo" alt="Partner 2">
            </div>
            
           
          </div>
        </div>
      </section>
      
    <!-- Newsletter Section -->
    <section class="newsletter-section py-5">
        <div class="container text-center">
          <h2 class="text-white fw-bold display-5 mb-4">
            Setiap kisah adalah perjalanan jiwa
          </h2>
          
          <form class="d-flex justify-content-center flex-wrap gap-2 mb-3">
            <input type="email" class="form-control form-control-lg email-input" placeholder="Pos el">
            <button type="submit" class="btn btn-light btn-lg fw-semibold">Mulai</button>
          </form>
      
          <p class="text-white-50">
            Jangan lewatkan cerita terbaru dari SETARA, langsung ke inbox Anda

          </p>
        </div>
      </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/bryanhanggara/PROJEK/jelita_v1/resources/views/welcome.blade.php ENDPATH**/ ?>