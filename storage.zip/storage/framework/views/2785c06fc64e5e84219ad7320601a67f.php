<?php $__env->startSection('content'); ?>
<!-- Hero Section -->
<section class="hero-section">
    <div class="container my-5">
        <div class="hero row align-items-center">
          <div class="col-lg-12 hero-text text-center">
            <h1 class="display-5 mb-3">Setiap kisah adalah suara hati <br> yang layak didengar</h1>
            <p>Tempat di mana kisah-kisah singkat perempuan hebat Indonesia dituangkan. <br> Setiap cerita ditulis dalam tiga paragraf yang mencerminkan pengalaman, perasaan, dan harapan.</p>
            <a href="#list" class="btn btn-pink mt-3">Baca Cerita</a>
          </div>
        </div>
      </div>
</section>

<!--Form Section-->
<section id="list" class="py-1">
    <div class="container">
      <ul class="nav nav-tabs border-0 mb-4">
        <li class="nav-item">
          <a class="nav-link fw-bold <?php echo e(empty($activeCategory) ? 'active' : ''); ?>" href="<?php echo e(route('pojok-cerita.index')); ?>">Semua</a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?php echo e(($activeCategory ?? '') === 'CERPEN' ? 'active' : ''); ?>" href="<?php echo e(route('pojok-cerita.index', ['category' => 'cerpen'])); ?>">Cerpen</a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?php echo e(($activeCategory ?? '') === 'PUISI' ? 'active' : ''); ?>" href="<?php echo e(route('pojok-cerita.index', ['category' => 'puisi'])); ?>">Puisi</a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?php echo e(($activeCategory ?? '') === 'KARYA PEGAWAI' ? 'active' : ''); ?>" href="<?php echo e(route('pojok-cerita.index', ['category' => 'karya-pegawai'])); ?>">Karya Pegawai</a>
        </li>
        <li class="nav-item ms-auto">
          <a class="nav-link text-muted" href="<?php echo e(route('pojok-cerita.index')); ?>">See All</a>
        </li>
      </ul>
  
      <div class="row g-4">
        <?php $__empty_1 = true; $__currentLoopData = ($posts ?? []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <div class="col-lg-4 col-md-6">
            <div class="article-card">
              <img src="<?php echo e($post->image ? asset('storage/'.$post->image) : 'https://via.placeholder.com/400x200?text=No+Image'); ?>" 
                   class="card-img-top rounded-4" alt="<?php echo e($post->title); ?>">
              <div class="card-body px-0">
                <div class="article-meta mb-2">
                  <br>
                  <span class="text-pink fw-bold"><?php echo e($post->category); ?></span>
                  <span class="text-muted ms-2"><?php echo e(optional($post->created_at)->format('d M Y')); ?></span>
                </div>
                <h5 class="fw-bold text-dark"><?php echo e($post->title); ?></h5>
                <p class="text-muted small"><?php echo \Illuminate\Support\Str::limit(strip_tags($post->body), 140); ?></p>
                <a href="<?php echo e(route('pojok-cerita.thumb', $post->id)); ?>" class="text-pink fw-bold text-decoration-none">Read More...</a>
              </div>
            </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <div class="col-12">
            <div class="alert alert-light text-center">Belum ada cerita untuk kategori ini.</div>
          </div>
        <?php endif; ?>
      </div>

      <?php if(($posts ?? null) && method_exists($posts, 'hasPages') && $posts->hasPages()): ?>
        <div class="mt-4">
          <?php echo e($posts->links()); ?>

        </div>
      <?php endif; ?>
    </div>
  </section>
  
  <!-- CSS tambahan -->
  <style>
    .dot {
      width: 8px;
      height: 8px;
      border-radius: 50%;
      display: inline-block;
    }
  </style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/bryanhanggara/PROJEK/jelita_v1/resources/views/pages/pojok-cerita/index.blade.php ENDPATH**/ ?>